# Virtual-Mouse
Project using python ml to create a virtual mouse which works by hand movements without the help of any hardware.
Virtual Mouse: Through this project we try to improve our knowledge of Python 
by practicing our existing skills in some real world application. We decided to 
make a system that can use hand/fingers motions as input and can enable one to 
control cursor without actually using a physical mouse or touchpad.
In the digital information time, daily life is inseparable with human-computer 
interface (HCI). Human computer interaction has a long history to become more 
intuitive. For human being, hand gesture of different kind is one of the most 
intuitive and common communication.
Human Computer Interaction with a personal computer today is not just limited to 
keyboard and mouse interaction. Interaction between humans comes from 
different sensory modes like gesture, speech, facial and body expressions.
However, vision-based hand gesture recognition is still a challenging problem. In 
this project an embedded virtual mouse system by using hand gesture recognition 
is proposed. 
This project was built keeping in mind about latest advancements in technology i.e 
AI and image processing and it would also help people to use their systems more 
freely and easily.
